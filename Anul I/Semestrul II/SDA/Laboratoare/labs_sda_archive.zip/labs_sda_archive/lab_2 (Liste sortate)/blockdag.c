// Zarojanu Mihnea Bogdan, 312CD

#include "blockdag.h"

Node *create_node (char *value) {
    Node *newNode = (Node*) malloc(sizeof(Node));
    newNode->value = strdup(value);
    return newNode;
}

Graph *allocate_graph (int node_number) {
    Graph *graph = (Graph*) malloc(sizeof(Graph));
    graph->number = node_number;
    graph->arr_list = (Node**) malloc(graph->number * sizeof(Node*));
    
    for(int i = 0; i < graph->number; i++){
        graph->arr_list[i] = NULL;
    }
    
    return graph;
}

void populate_graph (Graph* graph, FILE *fin) {

    for (int i = 0; i < graph->number; i++) {
        char *value = (char*) malloc(max_size * sizeof(char));
        fscanf(fin, "%s", value);

        Node *newNode = create_node(value);
        graph->arr_list[i] = newNode;

        free(value);
    }

    char *arch_list, sep[] = " :\n", *char_p;
    arch_list = (char*) malloc(max_size * sizeof(char));
    fscanf(fin, "%s", arch_list);

    for (int i = 0; i < graph->number; i++) {

        fgets(arch_list, max_size, fin);

        char_p = strtok(arch_list, sep);

        if (char_p != NULL) {
            int index = get_index(graph, char_p);
            char_p = strtok(NULL, sep);

            while (char_p != NULL) {
                char *value = strdup(char_p);
                Node *newNode = create_node(value);
                free(value);

                newNode->next = graph->arr_list[index]->next;
                graph->arr_list[index]->next = newNode;
                char_p = strtok(NULL, sep);
            }
        }
    }

    free(arch_list);
}

int get_index (Graph *graph, char *value) {
    for (int i = 0; i < graph->number; i++) {
        if (strcmp(graph->arr_list[i]->value, value) == 0) {
            return i;
        }
    }

    return -1;
}

void print_graph (Graph *graph) {
    for (int i = 0; i < graph->number; i++) {
        Node *currNode = graph->arr_list[i];
        while (currNode != NULL) {
            printf("%s ", currNode->value);
            currNode = currNode->next;
        }

        printf("\n");
    }
}

void empty_graph (Graph *graph) {
    for (int i = 0; i < graph->number; i++) {
        Node *currNode = graph->arr_list[i];
        Node *delNode = NULL;

        while (currNode != NULL) {
            delNode = currNode;
            currNode = currNode->next;
            free(delNode->value);
            free(delNode);
        }
    }

    free(graph->arr_list);
    free(graph);
}

int is_linked (Graph *graph, char* linker, char* linkee) {
    int *queue = (int*) malloc(max_size * sizeof(int));
    int queue_start = 0, queue_end = -1;

    int *visited = (int*) malloc(graph->number * sizeof(int));
    for (int i = 0; i < graph->number; i++) {
        visited[i] = 0;
    }

    queue[++queue_end] = get_index(graph, linker);
    while (queue_start <= queue_end) {
        int index = queue[queue_start++]; 
        Node* currNode = graph->arr_list[index]->next;
        
        while (currNode != NULL) {
            index = get_index(graph, currNode->value);
            
            if (!visited[index]) {
                if (strcmp(currNode->value, linkee) == 0) {
                    
                    free(queue);
                    free(visited);
                    
                    return 1;
                }
                visited[index] = 1;
                queue[++queue_end] = index;
            }

            currNode = currNode->next;
        }
    }

    free(queue);
    free(visited);

    return 0;
}

int is_acyclic (Graph *graph) {

    for (int i = 0; i < graph->number; i++) {
        if(is_linked(graph, graph->arr_list[i]->value, graph->arr_list[i]->value)){
            return 0;
        }
    }

    return 1;
}

void print_indexes (FILE* fout, Graph* graph, int* indexes) {

    // indexes[0] contine nr. de elemente
    for(int i = 1; i <= indexes[0]; i++){
        fprintf(fout, "%s ", graph->arr_list[indexes[i]]->value);
    }
    fprintf(fout, "\n");
}

int *past (Graph *graph, char* value) {

    // prima pozitie a listei retine nr. de elemente
    int *past_list = (int*) malloc((graph->number + 1) * sizeof(int));

    int *stack = (int*) malloc(graph->number * sizeof(int));
    int stack_top = 0;
    int *visited = (int*) malloc(graph->number * sizeof(int));

    for (int i = 0; i < graph->number; i++) {
        visited[i] = 0;
    }

    stack[stack_top++] = get_index(graph, value);
    while (stack_top > 0) {
        int index = stack[--stack_top];
        Node* currNode = graph->arr_list[index]->next;
        
        while (currNode != NULL) {
            index = get_index(graph, currNode->value);
            
            if (!visited[index]) {
                visited[index] = 1;
                stack[stack_top++] = index;
            }

            currNode = currNode->next;
        }
    }

    int cnt = 0;

    if (visited[0]) {
        past_list[++cnt] = 0;
        visited[0] = 0;
    }

    int check;

    char* minimum;
    do {
        check = 0;
        minimum = NULL;
        for (int i = 0; i < graph->number; i++) {
            if (visited[i]) {
                check = 1; 

                if (minimum == NULL){
                    minimum = graph->arr_list[i]->value;
                }

                if (strcmp(minimum, graph->arr_list[i]->value) > 0) {
                    minimum = graph->arr_list[i]->value;
                }
            }
        }
        
        if (check) {
            int index = get_index(graph, minimum);
            visited[index] = 0;
            past_list[++cnt] = index;
        }

    } while (check);

    past_list[0] = cnt;

    free(stack);
    free(visited);

    return past_list;
}

int *future (Graph *graph, char* value) {

    // prima pozitie a listei retine nr. de elemente
    int *future_list = (int*) malloc((graph->number + 1) * sizeof(int));

    int *visited = (int*) malloc(graph->number * sizeof(int));

    for (int i = 0; i < graph->number; i++){
        visited[i] = 0;
    }

    for (int i = 0; i < graph->number; i++){
        char* currValue = graph->arr_list[i]->value;
        if (is_linked(graph, currValue, value)){
            visited[i] = 1;
        }
    }

    int cnt = 0;

    if (visited[0]) {
        future_list[++cnt] = 0;
        visited[0] = 0;
    }

    int check;

    char* minimum;
    do {
        check = 0;
        minimum = NULL;
        for (int i = 0; i < graph->number; i++) {
            if (visited[i]) {
                check = 1; 

                if (minimum == NULL){
                    minimum = graph->arr_list[i]->value;
                }

                if (strcmp(minimum, graph->arr_list[i]->value) > 0) {
                    minimum = graph->arr_list[i]->value;
                }
            }
        }
        
        if (check) {
            int index = get_index(graph, minimum);
            visited[index] = 0;
            future_list[++cnt] = index;
        }

    } while (check);

    future_list[0] = cnt;

    free(visited);

    return future_list;
}

int *anticone (Graph *graph, char* value) {
    int *past_list = past(graph, value);
    int *future_list = future(graph, value);
    int *visited = (int*) malloc(graph->number * sizeof(int));

    int *anticone_list = (int*) malloc(graph->number * sizeof(int));

    for (int i = 0; i < graph->number; i++){
        visited[i] = 1;
    }

    visited[get_index(graph, value)] = 0;

    for (int i = 1; i <= past_list[0]; i++){
        visited[past_list[i]] = 0;
    }
    
    for (int i = 1; i <= future_list[0]; i++){
        visited[future_list[i]] = 0;
    }

    int cnt = 0;

    if (visited[0]) {
        anticone_list[++cnt] = 0;
        visited[0] = 0;
    }

    int check;

    char* minimum;
    do {
        check = 0;
        minimum = NULL;
        for (int i = 0; i < graph->number; i++) {
            if (visited[i]) {
                check = 1; 

                if (minimum == NULL){
                    minimum = graph->arr_list[i]->value;
                }

                if (strcmp(minimum, graph->arr_list[i]->value) > 0) {
                    minimum = graph->arr_list[i]->value;
                }
            }
        }
        
        if (check) {
            int index = get_index(graph, minimum);
            visited[index] = 0;
            anticone_list[++cnt] = index;
        }

    } while (check);

    anticone_list[0] = cnt;

    free(visited);
    free(past_list);
    free(future_list);

    return anticone_list;
}

int *tips (Graph *graph) {

    // prima pozitie a listei retine nr. de elemente
    int *tips_list = (int*) malloc((graph->number + 1) * sizeof(int));

    int cnt = 0;

    int *visited = (int*) malloc(graph->number * sizeof(int));

    for (int i = 0; i < graph->number; i++){
        visited[i] = 0;
    }

    for (int i = 0; i < graph->number; i++) {
        char *currValue = graph->arr_list[i]->value;
        int is_tip = 1;
        for (int j = 0; is_tip && j < graph->number; j++) {
            char *checkParent = graph->arr_list[j]->value;
            if (is_linked(graph, checkParent, currValue)) {
                is_tip = 0; 
            }
        }

        if (is_tip) {
            visited[i] = 1;
        }
    }

    if (visited[0]) {
        tips_list[++cnt] = 0;
        visited[0] = 0;
    }

    int check;

    char* minimum;
    do {
        check = 0;
        minimum = NULL;
        for (int i = 0; i < graph->number; i++) {
            if (visited[i]) {
                check = 1; 

                if (minimum == NULL){
                    minimum = graph->arr_list[i]->value;
                }

                if (strcmp(minimum, graph->arr_list[i]->value) > 0) {
                    minimum = graph->arr_list[i]->value;
                }
            }
        }
        
        if (check) {
            int index = get_index(graph, minimum);
            visited[index] = 0;
            tips_list[++cnt] = index;
        }

    } while (check);

    tips_list[0] = cnt;

    free(visited);

    return tips_list;
}

int main (int argc, char *argv[]) {
    
    if (argc < 2) {
        return 0;
    }

    FILE *fin, *fout;
    fin = fopen("blockdag.in", "r");
    fout = fopen("blockdag.out", "w");

    if (strcmp(argv[1], "-c1") == 0) {
        int node_number;
        fscanf(fin, "%d", &node_number);

        Graph *graph = allocate_graph(node_number);
        populate_graph(graph, fin);
        
        if (is_acyclic(graph)) {
            fprintf(fout, "correct\n");
        } else {
            fprintf(fout, "impossible\n");
        }

        empty_graph(graph);
    }

    if (strcmp(argv[1], "-c2") == 0) {
        if (argc < 3){
            fclose(fin);
            fclose(fout);
            return 0;
        }

        int node_number;
        fscanf(fin, "%d", &node_number);

        Graph *graph = allocate_graph(node_number);
        populate_graph(graph, fin);

        char* value = strdup(argv[2]);

        int *past_list = past(graph, value);
        int *future_list = future(graph, value);
        int *anticone_list = anticone(graph, value);
        int *tips_list = tips(graph);

        fprintf(fout, "past(%s) : ", value);
        print_indexes(fout, graph, past_list);
        
        fprintf(fout, "future(%s) : ", value);
        print_indexes(fout, graph, future_list);

        fprintf(fout, "anticone(%s) : ", value);
        print_indexes(fout, graph, anticone_list);
        
        fprintf(fout, "tips(G) : ");
        print_indexes(fout, graph, tips_list);

        free(past_list);
        free(future_list);
        free(anticone_list);
        free(tips_list);

        free(value);

        empty_graph(graph);

    }

    if (strcmp(argv[1], "-c3") == 0) {

        int node_number;
        fscanf(fin, "%d", &node_number);

        Graph *graph = allocate_graph(node_number);
        populate_graph(graph, fin);

        empty_graph(graph);

    }

    fclose(fin);
    fclose(fout);

    return 0;
}
