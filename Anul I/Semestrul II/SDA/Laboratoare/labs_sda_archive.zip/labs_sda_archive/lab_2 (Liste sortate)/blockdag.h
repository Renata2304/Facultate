// Zarojanu Mihnea Bogdan, 312CD

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max_size 200

typedef struct Node {
    char *value;
    struct Node *next;
} Node;

typedef struct {
    int number;
    Node **arr_list;
} Graph;

Node *create_node (char *value);
Graph *allocate_graph (int node_number);
void populate_graph (Graph* graph, FILE *fin);

int get_index (Graph *graph, char *value);
void print_graph (Graph *g);

int is_acyclic (Graph *graph);

void print_indexes (FILE* fout, Graph* graph, int* indexes);

int *past (Graph *graph, char* value);
int *future (Graph *graph, char* value);
int *anticone (Graph *graph, char* value);
int *tips (Graph *graph);

void empty_graph (Graph *graph);