#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "Util.h"
#include "Graph.h"

TGraphL* createGraphAdjList(int numberOfNodes) {
	TGraphL* graph = (TGraphL*) malloc(sizeof(TGraphL));
	graph->nn = numberOfNodes;
	graph->adl = (TNode**) malloc(graph->nn * sizeof(TNode*));
	for(int i = 0; i < graph->nn; i++){
		graph->adl[i] = NULL;
	}
	return graph;
}

void addEdgeList(TGraphL* graph, int v1, int v2) {
	if(graph == NULL){
		return;
	}
	TNode* node1 = (TNode*) malloc(sizeof(TNode));
	TNode* node2 = (TNode*) malloc(sizeof(TNode));

	node1->v = v2;
	node2->v = v1;
	
	node1->next = graph->adl[v1];
	graph->adl[v1] = node1;

	node2->next = graph->adl[v2];
	graph->adl[v2] = node2;
}

void dfsRecHelper(TGraphL* graph, int* visited, List* path, int s) {
	visited[s] = 1;
	enqueue(path, s);
	for(TNode* it = graph->adl[s]; it != NULL; it = it->next){
		if(visited[it->v] == 0){
			dfsRecHelper(graph, visited, path, it->v);
		}
	}
}

List* dfsRecursive(TGraphL* graph, int s) {
	List* path = createList();
	int* visited = (int*) malloc(graph->nn * sizeof(int));
	for(int i = 0; i < graph->nn; i++){
		visited[i] = 0;
	}
	dfsRecHelper(graph, visited, path, s);
	free(visited);
	return path;
}

List* bfs(TGraphL* graph, int s){
	// TODO: 3
	List* path = createList();
	int* visited = (int*) malloc(graph->nn * sizeof(int));
	for(int i = 0; i < graph->nn; i++){
		visited[i] = 0;
	}
	Queue* q = createQueue();
	enqueue(q, s);
	visited[s] = 1;
	while(isQueueEmpty(q) == 0){
		s = front(q);
		dequeue(q);
		enqueue(path, s);
		for(TNode* it = graph->adl[s]; it != NULL; it = it->next){
			if(visited[it->v] == 0){
				visited[it->v] = 1;
				enqueue(q, it->v);
			}
		}
	}
	destroyQueue(q);
	free(visited);
	return path;
}


void destroyGraphAdjList(TGraphL* graph){
	// TODO: 4
	for(int i = 0; i < graph->nn; i++){
		TNode* curr;
		curr = graph->adl[i];
		while(curr != NULL){
			TNode* copy = curr;
			curr = curr->next;
			free(copy);
		}
	}
	free(graph->adl);
	free(graph);
}

void removeEdgeList(TGraphL* graph, int v1, int v2){
	TNode* it = graph->adl[v1];
	TNode* prev = NULL;
	while(it != NULL && it->v != v2){
		prev = it;
		it = it->next;
	}

	if(it == NULL)return;

	if(prev != NULL)
		prev->next = it->next;
	else
		graph->adl[v1] = it->next;
	free(it);

	it = graph->adl[v2];
	prev = NULL;
	while(it != NULL && it->v != v1){
		prev = it;
		it = it->next;
	}
	if(it == NULL) return;
	if(prev != NULL)
		prev->next = it->next;
	else
		graph->adl[v2] = it->next;

	free(it);
}

void removeNodeList(TGraphL* graph, int v){
	for(int i = 0; i < graph->nn;i++){
		removeEdgeList(graph,v,i);
	}
}
