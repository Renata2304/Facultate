#ifndef __HEAP_H__
#define __HEAP_H__

#include <stdlib.h>
#include <math.h>

/* We assume there is a defined primitive type Item. */
typedef struct {
	int prior; // Item priority
	Item data; // Item d
}ItemType;

typedef struct heap{
	long maxHeapSize; // capacity
	long size; // number of elements
	ItemType *elem; // array of elements
} PriQueue, *APriQueue;


PriQueue* makeQueue(int maxHeapSize){
	APriQueue heap = (APriQueue) malloc(sizeof(PriQueue));
	heap->maxHeapSize = maxHeapSize;
	heap->size = 0;
	heap->elem = (ItemType*) calloc(heap->maxHeapSize, sizeof(ItemType));

	//TODO:
	return heap;
}

int getLeftChild(int i){
	//TODO:
	return ((i << 1) + 1);
}

int getRightChild(int i) {
	//TODO:
	return ((i + 1) << 1);
}

int getParent(int i) {
	//TODO:
	return ((i - 1) >> 1);
}

ItemType getMax(APriQueue h) {
	//TODO:
	return h->elem[0];
}

void siftUp(APriQueue h, int idx) {
	//TODO:
	int p = getParent(idx);
	while(p >= 0 && h->elem[idx].prior > h->elem[p].prior){
		ItemType aux = h->elem[p];
		h->elem[p] = h->elem[idx];
		h->elem[idx] = aux;
		idx = p;
		p = getParent(idx);
	}
}


void insert(PriQueue *h, ItemType x) {
	//TODO:
	if(h->size == h->maxHeapSize){
		h->maxHeapSize <<= 1;
		h->elem = (ItemType*) realloc(h->elem, sizeof(ItemType) * h->maxHeapSize);
	}
	h->elem[h->size] = x;
	siftUp(h, h->size);
	h->size++;
}

void siftDown(APriQueue h, int idx){
	//TODO:
	int largest = idx;
	do{
		idx = largest;
		int left = getLeftChild(idx);
		int right = getRightChild(idx);
		if(h->elem[left].prior > h->elem[idx].prior){
			largest = left;
		}
		if(h->elem[right].prior > h->elem[idx].prior){
			largest = right;
		}
		if(idx != largest){
			ItemType aux = h->elem[largest];
			h->elem[largest] = h->elem[idx];
			h->elem[idx] = aux;
		}
	}while(largest != idx);
}

void removeMax(APriQueue h) {
	//TODO:
	h->elem[0] = h->elem[h->size - 1];
	h->size--;
	siftDown(h, 0);
}

void freeQueue(APriQueue h){
	free(h->elem);
	free(h);
	// TODO:
}
#endif

