#ifndef TREE_H_D
#define TREE_H_

#include <stdio.h>
#include <stdlib.h>

typedef int Item;

typedef struct Link{
    Item  elem;
    struct Link *l;
    struct Link *r;
  } TreeNode;



void Init(TreeNode **t, Item x){
  (*t) = (TreeNode*) malloc (sizeof(TreeNode));
  (*t)->elem = x;
  (*t)->l = NULL;
  (*t)->r = NULL;
}

void Insert(TreeNode **t, Item x){
  if((*t) == NULL){
    printf("%d\n\n", x);
    Init(t, x);
    return;
  }
  if((*t)->elem == x){
    return;
  }
  if((*t)->elem > x){
    printf("left\n");
    &t = &t->l;
    Insert(t, x);
    return;
  }
  if((*t)->elem < x){
    &t = &t->r;
    printf("right\n");
    Insert(t, x);
    return;
  }
}

void PrintPostorder(TreeNode *t){
  if(t == NULL){
    return;
  }
  TreeNode* left = t->l;
  TreeNode* right = t->r;
  PrintPostorder(left);
  PrintPostorder(right);
  printf("%d ", t->elem);
}

void PrintPreorder(TreeNode *t){
  if(t == NULL){
    return;
  }
  TreeNode* left = t->l;
  TreeNode* right = t->r;
  printf("%d ", t->elem);
  PrintPostorder(left);
  PrintPostorder(right);
}

void PrintInorder(TreeNode *t){
  if(t == NULL){
    return;
  }
  TreeNode* left = t->l;
  TreeNode* right = t->r;
  PrintPostorder(left);
  printf("%d ", t->elem);
  PrintPostorder(right);
}

void Free(TreeNode **t){

}

int Size(TreeNode *t){
  return 0;
}

int maxDepth(TreeNode *t){
  return 0;
}

#endif // LINKEDSTACK_H_INCLUDED
