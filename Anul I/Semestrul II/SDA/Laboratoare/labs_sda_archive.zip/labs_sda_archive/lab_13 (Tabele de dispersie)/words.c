#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* Key;
typedef int Value;
typedef long(*HashFunction)(Key, long);

typedef struct Element {
  Key key;
  Value value;
  struct Element *next;
} Element;

typedef struct HashTable {
  Element** elements;
  long size;
  HashFunction hashFunction;
} HashTable;

void initHashTable(HashTable **h, long size, HashFunction f) {
  // Cerinta 1
  (*h) = (HashTable*) malloc(sizeof(HashTable));
  (*h)->elements = (Element**) malloc(size*sizeof(Element*));
  for(int i = 0; i < size; i++)
    (*h)->elements[i] = NULL;
  (*h)->size = size;
  (*h)->hashFunction = f;
}

int exists(HashTable *hashTable, Key key) {
  // Cerinta 1
  long idx = hashTable->hashFunction(key, hashTable->size);

  Element* it = hashTable->elements[idx];

  while(it != NULL){
    if(!strcmp(key, it->key)){
      return 1;
    }
    it = it->next;
  }

  return 0;
}

Value get(HashTable *hashTable, Key key) {
  // Cerinta 1
  long idx = hashTable->hashFunction(key, hashTable->size);
  Element* it = hashTable->elements[idx];
  while(it != NULL){
    if(!strcmp(key, it->key)){
      return it->value;
    }
    it = it->next;
  }

  return 0;
}

void put(HashTable *hashTable, Key key, Value value) {
  // Cerinta 1
  long idx = hashTable->hashFunction(key, hashTable->size);
  Element* it = hashTable->elements[idx];

  while(it != NULL){
    if(!strcmp(key, it->key)){
      it->value = value;
      return;
    }
    it = it->next;
  }

  Element* e = (Element*) malloc(sizeof(Element));
  e->key = strdup(key);
  e->value = value;

  e->next = hashTable->elements[idx];
  hashTable->elements[idx] = e;
}

void deleteKey(HashTable *hashTable, Key key) {
  // Cerinta 1
  long idx = hashTable->hashFunction(key, hashTable->size);

  Element* e = hashTable->elements[idx];

  if(!strcmp(e->key, key)){
    hashTable->elements[idx] = e->next;
    free(e->key);
    free(e);
    return;
  }

  Element* prev = NULL;
  while(strcmp(e->key, key)){
    prev = e;
    e = e->next;
  }
  prev->next = e->next;
  free(e->key);
  free(e);

}

void print(HashTable *hashTable) {
  long idx;
  Element *e;
  printf("---START---\n");
  for (idx = 0; idx < hashTable->size; idx++) {
    e = hashTable->elements[idx];
    if (e != NULL) {
      printf("%ld:\n", idx);
      while (e != NULL) {
        printf("\t%s : %d\n", e->key, e->value);
        e = e->next;
      }
    }
  }
  printf("----END----\n");
}

void freeHashTable(HashTable *hashTable) {
  Element *e1, *e2;
  long idx;

  for (idx = 0; idx < hashTable->size; idx++) {
    e1 = hashTable->elements[idx];
    while (e1 != NULL) {
      e2 = e1->next;
      free(e1->key);
      free(e1);
      e1 = e2;
    }
  }
  free(hashTable->elements);
  free(hashTable);
}

long hash1(Key word, long size) {
  // Cerinta 2
  long h = 0;
  for(int i = 0; i < strlen(word); i++){
    h = h*17 + word[i];
  }

  return h % size;
}

int main(int argc, char* argv[]) {
  HashTable *hashTable;
  FILE *f1, *f2;
  char word[256];
  long hashSize, common = 0;
  if(argc < 4)
    exit(1);
  hashSize = atoi(argv[1]);
  f1 = fopen(argv[2], "r");
  f2 = fopen(argv[3], "r");

  initHashTable(&hashTable, hashSize, &hash1);

  // Cerinta 3

  while(fscanf(f1, "%s", word) != EOF) {
    if (exists(hashTable, word)) {
      put(hashTable, word, get(hashTable, word) + 1);
    } else {
      put(hashTable, word, 1);
    }
  }
  print(hashTable);

  // Cerinta 4

  long cnt;
  while(fscanf(f2, "%s", word) != EOF) {
    if (exists(hashTable, word)) {
      common = common + 1l;
      cnt = get(hashTable, word);
      if (cnt == 1) {
        deleteKey(hashTable, word);
      } else {
        put(hashTable, word, cnt-1);
      }
    }
  }


  printf("Common words: %ld\n", common);


  freeHashTable(hashTable);
  fclose(f1);
  fclose(f2);
  return 0;
}
